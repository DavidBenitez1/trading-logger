# Trading Logger v2

App para registrar operaciones de trading con estadísticas, fase estructural, patrones de entrada, y capturas del antes y después.

## Funcionalidades
- Registro de fase del fractal, temporalidad y patrón de entrada
- Cálculo de estadísticas por patrón
- Carga de imágenes del antes y el después
- Guardado local automático en el navegador

## Uso
Abrí el proyecto con `npm start` y comenzá a registrar tus operaciones.